#include <winsock2.h>
#include <stdio.h>
#include <iostream>
#define _WINSOCK_DEPRECATED_NOWARNINGS
#define _CRT_SECURE_NO_WARNINGS
#pragma comment(lib,"ws2_32.lib")
using namespace std;
int main()
{
	char Buf[1024];
	while (1)
	{
		WSADATA wsadata;
		if (0 != WSAStartup(MAKEWORD(2, 2), &wsadata))
		{
			cout << "Socket��ʧ�ܣ�" << endl;
			return 0;
		}
		else
		{
			cout << "�Ѵ�Socket" << endl;
		}
		SOCKET serSocket = socket(AF_INET, SOCK_STREAM, 0);
		SOCKADDR_IN addr;
		addr.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
		addr.sin_family = AF_INET;
		addr.sin_port = htons(6000);
		bind(serSocket, (SOCKADDR*)&addr, sizeof(SOCKADDR));
		listen(serSocket, 1024);
		SOCKADDR_IN clientsocket;
		int len = sizeof(SOCKADDR);
		SOCKET serConn = accept(serSocket, (SOCKADDR*)&clientsocket, &len);
		if (serConn != -1)
		{
			cout << "��ͻ������ӳɹ�" << endl;
			recv(serConn, Buf, 1024, 0);
			cout << "������յ�:" << Buf << endl;
			cout << "����˻ظ���" << Buf << endl;
			send(serConn, Buf, 1024, 0);
		}
		else
		{
			cout << "��ͻ�������ʧ�ܣ�" << endl;
		}
		closesocket(serConn);
		WSACleanup();
	}
	return 0;
}
