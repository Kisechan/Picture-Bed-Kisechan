#include "Dijkstra.h"
using namespace std;
void Graph::MakeMatrix()
{
	cout << "���������ͱ���" << endl;
	cin >> this->vnum >> this->anum;
	vector<int>temp(this->vnum, INF);
	matrix.clear();
	for (int i = 0; i < this->vnum; i++)
	{
		matrix.push_back(temp);
	}
	for (int i = 0; i < this->anum; i++)
	{
		int v1, v2, w;
		cout << "�������" << i + 1 << "���ߵ���㡢�յ�(��0��ʼ)�����Ӧ��Ȩֵ" << endl;
		cin >> v1 >> v2 >> w;
		this->matrix[v1][v2] = w;
		this->matrix[v2][v1] = w;
	}
	return;
}
//void Graph::PrintMatrix()
//{
//	cout << "�ڽӾ������£�" << endl;
//	for (int i = 0; i < this->vnum; i++)
//	{
//		for (int j = 0; j < this->vnum; j++)
//		{
//			matrix[i][j] == INF ? printf("  INF") : i == j ? printf("    0") : printf("%5d", matrix[i][j]);
//			j + 1 < this->vnum ? putchar(' ') : putchar('\n');
//		}
//	}
//}
void Graph::Dijkstra(int start)
{
	for (int i = 0; i < this->vnum; i++)
	{
		this->d[i] = INF;
	}
	d[start] = 0;
	tagged[start] = true;
	queue<int>temp;
	temp.push(start);
	for (int i = 0; i < this->vnum; i++)
	{
		path.push_back(temp);
	}
	for (int i = 0; i < this->vnum; i++)
	{
		tagged[i] = false;
	}
	for (int i = 0; i < this->vnum; i++)
	{
		if (this->matrix[start][i] != INF)
		{
			d[i] = this->matrix[start][i];
			path[i].push(i);
		}
	}
	for (int i = 0; i < this->vnum; i++)
	{
		int target = INF;
		int v = i;
		for (int j = 0; j < this->vnum; j++)
		{
			if (!tagged[j] && d[j] < target)
			{
				target = d[j];
				v = j;
			}
			tagged[v] = true;
			int w;
			for (int i = 0; i < this->vnum; i++)
			{
				if (this->matrix[v][i] != INF)
					w = i;
			}
			while (w != -1)
			{
				if (d[v] + this->matrix[v][w] < d[w])
				{
					d[w] = d[v] + this->matrix[v][w];
					path[w] = path[v];
					path[w].push(w);
				}
				for (int i = v + 1; i < this->vnum; i++)
				{
					if (this->matrix[v][i] != INF)
						w = i;
				}
			}
		}
	}
	cout << "�ӽ��" << start << "��ʼ����������·����·����������:" << endl;
	for (int i = 0; i < this->vnum; i++)
	{
		if (d[i] == INF)
		{
			cout << "�޷�������" << i << endl;
		}
		else
		{
			cout << "������" << i << "�����·��Ϊ" << endl;
			for (int j = 0; j < path[i].size(); j++)
			{
				cout << path[i].front() << " ";
				path[i].pop();
			}
			cout << "����Ϊ" << d[i] << endl;
		}
	}
}