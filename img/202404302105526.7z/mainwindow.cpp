#include "mainwindow.h"
#include "ui_mainwindow.h"
using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("模拟寻路：Dijkstra算法");
    connect(ui->get,&QPushButton::clicked,this,&MainWindow::GraphD);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::GraphD()
{
    Graph graph;
    Build(graph);
    Dijkstra(graph);
    Print(graph);
    return;
}
void MainWindow::Build(Graph& graph)
{
    QString getVex=ui->Vex->text();
    QString getArc=ui->Arc->text();

    QByteArray VexA=getVex.toLocal8Bit();
    QByteArray ArcA=getArc.toLocal8Bit();

    char* Vex=VexA.data();
    char* Arc=ArcA.data();

    sscanf(Vex,"%d",&graph.vnum);
    sscanf(Arc,"%d",&graph.anum);

    vector<int>temp(graph.vnum,INF);
    graph.matrix.clear();
    for (int i=0;i<graph.vnum;i++)
    {
        graph.matrix.push_back(temp);
    }
    for (int i=0;i<graph.anum;i++)
    {
        QString Str;
        bool flag;
        cout<<i<<endl;
        char text[100];
        sprintf(text,"请输入第%d条边的数据",i+1);
        Str=QInputDialog::getText(this, text, "分别输入边的起点、终点（从0开始）和权重\n并用空格隔开",QLineEdit::Normal,"请输入",&flag,Qt::WindowFlags(),Qt::ImhNone);

        QByteArray StrA=Str.toLocal8Bit();
        char* StrC=StrA.data();
        int v1,v2,w;
        sscanf(StrC,"%d%d%d",&v1,&v2,&w);
        graph.matrix[v1][v2]=w;
        graph.matrix[v2][v1]=w;

    }
    graph.PrintMatrix();
    return;
}

void MainWindow::Dijkstra(Graph &graph)
{
    int start,end;

    QString getStart=ui->StartEdit->text();
    QString getEnd=ui->EndEdit->text();

    QByteArray s=getStart.toLocal8Bit();
    QByteArray e=getEnd.toLocal8Bit();

    char* S=s.data();
    char* E=e.data();

    sscanf(S,"%d",&start);
    sscanf(E,"%d",&end);

    for (int i = 0; i < graph.vnum; i++)
    {
        graph.d[i] = INF;
    }
    graph.d[start] = 0;
    graph.tagged[start] = true;
    queue<int>temp;
    temp.push(start);
    for (int i = 0; i < graph.vnum; i++)
    {
        graph.path.push_back(temp);
    }
    for (int i = 0; i < graph.vnum; i++)
    {
        graph.tagged[i] = false;
    }
    for (int i = 0; i < graph.vnum; i++)
    {
        if (graph.matrix[start][i] != INF)
        {
            graph.d[i] = graph.matrix[start][i];
            graph.path[i].push(i);
        }
    }
    for (int i = 0; i < graph.vnum; i++)
    {
        int target = INF;
        int v = i;
        for (int j = 0; j < graph.vnum; j++)
        {
            if (!graph.tagged[j] && graph.d[j] < target)
            {
                target = graph.d[j];
                v = j;
            }
            graph.tagged[v] = true;
            int w;
            bool flag=true;
            for (int i = 0; i < graph.vnum; i++)
            {
                if (graph.matrix[v][i] != INF)
                {
                    w=i;
                    flag=false;
                    break;
                }
            }
            if(flag)
            {
                w=-1;
            }
            while (w != -1)
            {
                if (graph.d[v] + graph.matrix[v][w] < graph.d[w])
                {
                    graph.d[w] = graph.d[v] + graph.matrix[v][w];
                    graph.path[w] = graph.path[v];
                    graph.path[w].push(w);
                }
                bool flag=true;
                for (int i = w + 1; i < graph.vnum; i++)
                {
                    if (graph.matrix[v][i] != INF)
                    {
                        w=i;
                        flag=false;
                        break;
                    }
                }
                if(flag)
                {
                    w=-1;
                }
            }
        }
    }

    if(graph.d[end]>=INF)
    {
        char text[100];
        sprintf(text,"无法从%d到达%d",start,end);
        ui->Result->setText(text);
        ui->Path->setText("不存在");
    }
    else
    {
        char text[100];
        sprintf(text,"从%d到达%d的距离为%d",start,end,graph.d[end]);
        ui->Result->setText(text);
    }
}
void MainWindow::Print(Graph& graph)
{
    int start,end;

    QString getStart=ui->StartEdit->text();
    QString getEnd=ui->EndEdit->text();

    QByteArray s=getStart.toLocal8Bit();
    QByteArray e=getEnd.toLocal8Bit();

    char* S=s.data();
    char* E=e.data();

    sscanf(S,"%d",&start);
    sscanf(E,"%d",&end);

    float mid=55.5;
    QGraphicsScene* scene = new QGraphicsScene();
    QGraphicsView* view = ui->graphicsView;
    QGraphicsEllipseItem* epItem[1000];
    QGraphicsLineItem* lineOrigin[1000];
    QGraphicsLineItem* lineItem[1000];
    QGraphicsSimpleTextItem* title=scene->addSimpleText("图示");
    QGraphicsSimpleTextItem* textItem[1000];
    QGraphicsSimpleTextItem* tagItem[1000];
    title->setX(mid);
    title->setY(-100);
    int x[100];
    int y[100];
    for(int i=0;i<graph.vnum;i++)
    {
        char text[100];
        int x2,y2;
        x[i]=mid+100*cos(i*2*3.14/graph.vnum);
        y[i]=mid+100*sin(i*2*3.14/graph.vnum);
        x2=mid+130*cos(i*2*3.14/graph.vnum);
        y2=mid+130*sin(i*2*3.14/graph.vnum);
        //epItem[i]=scene->addEllipse(x[i],y[i],20,20);
        //epItem[i]->setBrush(Qt::black);
        //epItem[i]->setPen(QPen(Qt::black));
        sprintf(text,"%d",i);
        QString tmp=text;
        textItem[i]=scene->addSimpleText(tmp);
        textItem[i]->setX(x2);
        textItem[i]->setY(y2);
    }
    int k=0;
    for (int i=0;i<graph.vnum;i++)
    {
        for (int j=i;j<graph.vnum;j++)
        {
            if(graph.matrix[i][j]!=INF&&i!=j)
            {
                lineOrigin[k]=scene->addLine(x[i],y[i],x[j],y[j]);
                char text[1000];
                sprintf(text,"%d",graph.matrix[i][j]);
                QString tag=text;
                tagItem[k]=scene->addSimpleText(tag);
                tagItem[k]->setX((x[i]+x[j])/2);
                tagItem[k]->setY((y[i]+y[j])/2);
                tagItem[k]->setPen(QPen(Qt::blue));
                k++;
            }
        }
    }
    if(end!=start)
    {
        int temp,i=0;
        QString text;
        char part[100];
        sprintf(part,"%d",start);
        text=part;
        while(graph.path[end].front()!=end)
        {
            temp=graph.path[end].front();
            graph.path[end].pop();
            sprintf(part,"->%d",graph.path[end].front());
            text=text+part;
            lineItem[i]=scene->addLine(x[temp],y[temp],x[graph.path[end].front()],y[graph.path[end].front()]);
            lineItem[i++]->setPen(QPen(Qt::red));
        }
        ui->Path->setText(text);
    }
    view->setScene(scene);
    view->setRenderHint(QPainter::Antialiasing);
    view->setDragMode(QGraphicsView::ScrollHandDrag);
    view->show();
}
