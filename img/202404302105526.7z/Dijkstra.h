#pragma once
#include <iostream>
#include <queue>
#include <vector>
#define INF 9999
#define Num 100
using namespace std;
class Graph
{
	int anum;
	int vnum;
	vector<vector<int>>matrix;
	vector<queue<int>>path;
	int d[Num];
	bool tagged[Num];
public:
	void MakeMatrix();
	//void PrintMatrix();
	void Dijkstra(int start);
};